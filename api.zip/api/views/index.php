<?php
// To call this page, in the browser type:
// http://localhost/

echo 'INDEX';